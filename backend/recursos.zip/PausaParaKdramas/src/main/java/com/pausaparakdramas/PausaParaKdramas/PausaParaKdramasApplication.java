package com.pausaparakdramas.PausaParaKdramas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PausaParaKdramasApplication {

	public static void main(String[] args) {
		SpringApplication.run(PausaParaKdramasApplication.class, args);
	}

}
