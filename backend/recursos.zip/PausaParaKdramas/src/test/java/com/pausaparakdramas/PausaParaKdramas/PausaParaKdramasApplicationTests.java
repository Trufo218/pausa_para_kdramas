package com.pausaparakdramas.PausaParaKdramas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PausaParaKdramasApplicationTests {

	@Test
	void contextLoads() {
	}

}
